# Ministério Evangélico Enraizados — Sistema de Gestão

Sistema web completo para gestão de ministérios evangélicos, desenvolvido com React + TypeScript + Tailwind CSS.

## 🚀 Acesso Rápido

Abra o arquivo `index.html` diretamente no seu navegador ou acesse via GitHub Pages.

## 📋 Funcionalidades

### Gestão de Pessoas
- ✝️ **Membros** — cadastro, edição, busca, status (Ativo/Pendente/Inativo)
- 🕊️ **Congregados** — registro de pessoas que frequentam a congregação
- ⚓ **Obreiros** — cadastro de pastores, diáconos e outros ministros

### Financeiro (Protegido por PIN)
- 📥 **Entradas** — registro de dízimos, ofertas, campanhas, doações
- 📤 **Dispensas** — registro de gastos (aluguel, energia, materiais, etc.)
- 📊 **Relatórios** — gráficos mensais/anuais com análise de fluxo

### Recursos Adicionais
- 🎂 **Aniversariantes** — visualização por mês com destaque para o dia
- 📜 **Certificados** — geração de PDFs para membros e obreiros
- 📢 **Lembretes de Culto** — envio automático via WhatsApp nos dias de culto
- 👥 **Cadastro Público** — link compartilhável para novos congregados se registrarem

## 🔐 Credenciais Padrão

| Acesso | Senha |
|--------|-------|
| Sistema | `1234` |
| Financeiro (PIN) | `123456` |

## 💾 Dados

Todos os dados são armazenados localmente no navegador (localStorage). Não há servidor envolvido — tudo funciona offline.

## 🎨 Design

- **Paleta**: Verde-musgo profundo + dourado âmbar + bege pergaminho
- **Tipografia**: Cinzel (títulos) + Crimson Text (versículos) + Inter (corpo)
- **Tema**: Organic Forest Church — design elegante e espiritual

## 📱 Compatibilidade

- ✅ Desktop (Chrome, Firefox, Safari, Edge)
- ✅ Mobile (iOS Safari, Android Chrome)
- ✅ Offline (após primeira visita)

## 🛠️ Desenvolvimento

Desenvolvido com:
- React 19
- TypeScript
- Tailwind CSS 4
- Recharts (gráficos)
- Wouter (roteamento)
- Sonner (notificações)

## 📝 Versículo Base

> "Enraizados e edificados nele, firmados na fé, como foram ensinados, transbordando de gratidão." — Colossenses 2:7

---

**Desenvolvido para o Ministério Evangélico Enraizados**
